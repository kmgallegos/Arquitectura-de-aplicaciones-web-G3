package pe.edu.upc.helpyou;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelpYouApplicationTests {

    @Test
    void contextLoads() {
    }

}
