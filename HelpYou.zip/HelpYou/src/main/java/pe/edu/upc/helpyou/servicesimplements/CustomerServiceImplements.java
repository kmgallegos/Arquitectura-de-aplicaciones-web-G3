package pe.edu.upc.helpyou.servicesimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.helpyou.entities.Customer;
import pe.edu.upc.helpyou.repositories.ICustomerRepository;
import pe.edu.upc.helpyou.servicesinterfaces.ICustomerService;

import java.util.List;

@Service
public class CustomerServiceImplements implements ICustomerService {
    @Autowired
    private ICustomerRepository cR;

    @Override
    public void insert(Customer customer) {
        cR.save(customer);
    }

    @Override
    public List<Customer> list() {
        return cR.findAll();
    }
}
