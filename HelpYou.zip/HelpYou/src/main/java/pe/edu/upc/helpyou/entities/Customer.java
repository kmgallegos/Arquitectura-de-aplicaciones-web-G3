package pe.edu.upc.helpyou.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "Customer")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_customer;

    @Id
    @Column (name = "dni",nullable = false,length = 8)
    private String dni;
    @Column (name = "nameCustomer",nullable = false,length = 50)
    private String nameCustomer;
    @Column (name = "lastNameCustomer",nullable = false, length = 50)
    private String lastNameCustomer;
    @Column (name = "phoneNumberCustomer",length = 9)
    private String phoneNumberCustomer;
    @Column (name = "photo",length = 200)
    private String photo;
    @Column (name = "role",length = 30)
    private String role;
    @Column (name = "password",nullable = false,length = 100)
    private String password;

    @Id
    @Column (name = "nickname",nullable = false,length = 30)
    private String nickname;
    @Column (name = "email",nullable = false,length = 100)
    private String email;
    @Column (name = "region",length = 30)
    private String region;

    public Customer() {
    }

    public Customer(int id_customer, String dni, String nameCustomer, String lastNameCustomer, String phoneNumberCustomer, String photo, String role, String password, String nickname, String email, String region) {
        this.id_customer = id_customer;
        this.dni = dni;
        this.nameCustomer = nameCustomer;
        this.lastNameCustomer = lastNameCustomer;
        this.phoneNumberCustomer = phoneNumberCustomer;
        this.photo = photo;
        this.role = role;
        this.password = password;
        this.nickname = nickname;
        this.email = email;
        this.region = region;
    }

    public int getId_customer() {
        return id_customer;
    }

    public void setId_customer(int id_customer) {
        this.id_customer = id_customer;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNameCustomer() {
        return nameCustomer;
    }

    public void setNameCustomer(String nameCustomer) {
        this.nameCustomer = nameCustomer;
    }

    public String getLastNameCustomer() {
        return lastNameCustomer;
    }

    public void setLastNameCustomer(String lastNameCustomer) {
        this.lastNameCustomer = lastNameCustomer;
    }

    public String getPhoneNumberCustomer() {
        return phoneNumberCustomer;
    }

    public void setPhoneNumberCustomer(String phoneNumberCustomer) {
        this.phoneNumberCustomer = phoneNumberCustomer;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }
}
