package pe.edu.upc.helpyou;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelpYouApplication {

    public static void main(String[] args) {
        SpringApplication.run(HelpYouApplication.class, args);
    }

}
