package pe.edu.upc.helpyou.servicesinterfaces;

import pe.edu.upc.helpyou.entities.Customer;

import java.util.List;

public interface ICustomerService {
    public void insert(Customer customer);
    public List<Customer> list();
}
